import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shopping/models/model_product.dart';
import 'package:shopping/utils/common.dart';
import 'package:shopping/viewmodels/post_view_model.dart';

class BookmarkPage extends StatelessWidget {
  const BookmarkPage({super.key});

  @override
  Widget build(BuildContext context) {
    final productViewModel = Provider.of<ProductViewModel>(context);

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        toolbarHeight: 72,
        title: const Center(
          child: Column(
            children: [
              Text(
                "Roasters",
                style: TextStyle(
                  color: Colors.black,
                  fontFamily: 'montserrat',
                  fontWeight: FontWeight.w800,
                  fontSize: 18,
                ),
              ),
              Text(
                "Discover our Roasters",
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 15,
                  fontFamily: 'montserrat',
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
      ),
      body: productViewModel.uiState == UiState.loading
          ? ListView.builder(
              itemCount: 20, // Number of shimmer items you want to show
              itemBuilder: (context, index) {
                return const ShimmerBookmarkLoading();
              },
            )
          : productViewModel.uiState == UiState.error
              ? Center(
                  child: ErrorStateWidget(
                    image: 'assets/svg/empty/NoNetState.svg',
                    title: 'No internet connection!',
                    subtitle: 'Please check your internet connection.',
                    onRetry: () {
                      productViewModel.fetchProducts('smartphones');
                    },
                  ),
                )
              : ListView.builder(
                  physics: const BouncingScrollPhysics(),
                  itemCount: productViewModel.products.length,
                  itemBuilder: (context, index) {
                    final post = productViewModel.products[index];
                    return ListBookmark(post: post);
                  },
                ),
    );
  }
}

class ListBookmark extends StatelessWidget {
  final Product post;

  const ListBookmark({super.key, required this.post});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16.0),
      onTap: () {
        // Handle list item tap here
      },
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(4.0),
        child: Image.network(
          post.thumbnail,
          fit: BoxFit.fitHeight,
        ),
      ),
      title: Text(
        post.title,
        maxLines: 1,
        style: const TextStyle(
          fontSize: 16,
          color: Colors.black,
          fontFamily: 'montserrat',
          fontWeight: FontWeight.w800,
        ),
      ),
      subtitle: Text(
        post.shippingInformation,
        maxLines: 1,
        style: const TextStyle(
          fontSize: 12,
          color: Colors.grey,
          fontFamily: 'montserrat',
          fontWeight: FontWeight.w600,
        ),
      ),
      tileColor: Colors.white,
      shape: const Border(
        bottom: BorderSide(color: Colors.grey, width: 0.2),
      ),
    );
  }
}
