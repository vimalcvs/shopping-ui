import 'package:flutter/material.dart';
import 'package:shopping/utils/common.dart';

class FavoritesPage extends StatelessWidget {
  const FavoritesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          toolbarHeight: 72,
          title: const Center(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("Favorites",
                    style: TextStyle(
                        color: Colors.black,
                        fontFamily: 'montserrat',
                        fontWeight: FontWeight.w800,
                        fontSize: 18)),
                Text(
                  "0 items(as) Favorites",
                  style: TextStyle(
                    color: Colors.grey,
                    fontSize: 15,
                    fontFamily: 'montserrat',
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          backgroundColor: const Color(0xFFFFFFFF),
          foregroundColor: const Color(0xFF000000),
        ),
        backgroundColor: const Color(0xFFFFFFFF),
        body: const EmptyStateWidget(
            image: "assets/svg/empty/EmptyInbox.svg",
            title: "Favorites",
            subtitle: "No results found Try"));
  }
}
