import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:lottie/lottie.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart'; // Import shared_preferences

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      systemNavigationBarColor: Colors.transparent,
    ),
  );
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

  // Check if onboarding has been completed
  final prefs = await SharedPreferences.getInstance();
  final bool hasCompletedOnboarding = prefs.getBool('onboardingComplete') ?? false;

  runApp(MyApp(hasCompletedOnboarding: hasCompletedOnboarding));
}

class MyApp extends StatelessWidget {
  final bool hasCompletedOnboarding;
  const MyApp({required this.hasCompletedOnboarding, super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: hasCompletedOnboarding ? MainScreen() : OnboardingScreen(),
    );
  }
}

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  _OnboardingScreenState createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController(initialPage: 0);
  int currentPage = 0;
  final int totalPages = 3;

  @override
  Widget build(BuildContext context) {
    WidgetsFlutterBinding.ensureInitialized();

    // Set full-screen mode with white status and navigation bars
    SystemChrome.setSystemUIOverlayStyle(
      const SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        statusBarBrightness: Brightness.dark,
        statusBarIconBrightness: Brightness.dark,
        systemNavigationBarColor: Colors.white,
        systemNavigationBarIconBrightness: Brightness.dark,
      ),
    );

    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: PageView(
              controller: _pageController,
              onPageChanged: (int page) {
                setState(() {
                  currentPage = page;
                });
              },
              children: [
                buildPage(
                    image: "assets/gifs/animation_1.json",
                    title: "Explore Service Providers",
                    description:
                    "Whether it's a videographer, makeup artist or a meme agency, access 1000’s of top service providers."),
                buildPage(
                    image: "assets/gifs/animation_2.json",
                    title: "Manage Your Projects",
                    description:
                    "Easily organize and manage your ongoing and completed projects with top professionals."),
                buildPage(
                    image: "assets/gifs/animation_3.json",
                    title: "Access Creative Services",
                    description:
                    "Find the best creative professionals for your design and artistic needs."),
              ],
            ),
          ),
          buildIndicator(),
          Padding(
            padding: const EdgeInsets.only(
                bottom: 100.0, left: 30.0, right: 30.0, top: 16.0),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                minimumSize: Size(double.infinity, 50),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30.0)),
              ),
              onPressed: () async {
                if (currentPage == totalPages - 1) {
                  // Save in SharedPreferences that onboarding is complete
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setBool('onboardingComplete', true);

                  // Navigate to the main screen
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (context) => MainScreen()),
                  );
                } else {
                  // Move to the next page
                  _pageController.nextPage(
                    duration: Duration(milliseconds: 300),
                    curve: Curves.easeInOut,
                  );
                }
              },
              child:
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(
                  currentPage == totalPages - 1 ? "Finish" : "Next",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    fontFamily: 'montserrat',
                  ),
                ),
                SizedBox(width: 5),
                Icon(
                  currentPage == totalPages - 1
                      ? Icons.check
                      : Icons.arrow_right_alt_rounded,
                  color: Colors.white,
                  size: 24,
                ),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Widget buildPage(
      {required String image,
        required String title,
        required String description}) {
    return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 50),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Lottie.asset(
              image,
              height: 300, // Path to your Lottie file
              fit: BoxFit.fill,
            ),
            SizedBox(height: 20),
            Text(
              title,
              style: TextStyle(
                fontSize: 20,
                color: Colors.black,
                fontWeight: FontWeight.w800,
                fontFamily: 'montserrat',
              ),
            ),
            SizedBox(height: 20),
            Text(
              description,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: Colors.black,
                fontWeight: FontWeight.w500,
                fontFamily: 'montserrat',
              ),
            ),
          ],
        ));
  }

  Widget buildIndicator() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(totalPages, (index) {
        return AnimatedContainer(
          duration: Duration(milliseconds: 300),
          height: 10,
          width: (index == currentPage) ? 25 : 10,
          margin: EdgeInsets.symmetric(horizontal: 5),
          decoration: BoxDecoration(
            color: (index == currentPage) ? Colors.red : Colors.grey.shade300,
            borderRadius: BorderRadius.circular(5),
          ),
        );
      }),
    );
  }
}

// Define the main screen here
class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Main Screen"),
      ),
      body: Center(
        child: Text("Welcome to the Main Screen!"),
      ),
    );
  }
}
