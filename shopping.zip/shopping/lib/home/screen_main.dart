import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:provider/provider.dart';
import 'package:shopping/home/screen_bookmark.dart';
import 'package:shopping/home/screen_favorites.dart';
import 'package:shopping/home/screen_home.dart';
import 'package:shopping/home/screen_profile.dart';
import 'package:shopping/home/screen_shopping.dart';
import 'package:shopping/home/screen_splash.dart';
import 'package:shopping/viewmodels/post_view_model.dart';

class MyApplication extends StatelessWidget {
  const MyApplication({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => ProductViewModel()..fetchProducts('smartphones'),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Shopping',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        ),
        home: const SplashScreen(),
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    const HomePage(),
    const BookmarkPage(),
    const ShoppingPage(),
    const FavoritesPage(),
    const ProfilePage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: SvgPicture.asset(
              _selectedIndex == 0
                  ? "assets/svg/ic_nav_home_fill.svg"
                  : "assets/svg/ic_nav_home.svg",
              width: 20,
              height: 20,

              color: _selectedIndex == 0 ? Colors.blue : Colors.grey,
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SvgPicture.asset(
              _selectedIndex == 1
                  ? "assets/svg/ic_nav_bookmark_fill.svg"
                  : "assets/svg/ic_nav_bookmark.svg",
              width: 20,
              height: 20,
              color: _selectedIndex == 1 ? Colors.blue : Colors.grey,
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SvgPicture.asset(
              _selectedIndex == 2
                  ? "assets/svg/ic_nav_shopping_fill.svg"
                  : "assets/svg/ic_nav_shopping.svg",
              width: 21,
              height: 21,
              color: _selectedIndex == 2 ? Colors.blue : Colors.grey,
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SvgPicture.asset(
              _selectedIndex == 3
                  ? "assets/svg/ic_nav_heart_fill.svg"
                  : "assets/svg/ic_nav_heart.svg",
              width: 21,
              height: 21,
              color: _selectedIndex == 3 ? Colors.blue : Colors.grey,
            ),
            label: '',
          ),
          BottomNavigationBarItem(
            icon: SvgPicture.asset(
              _selectedIndex == 4
                  ? "assets/svg/ic_nav_user_fill.svg"
                  : "assets/svg/ic_nav_user.svg",
              width: 21,
              height: 21,
              color: _selectedIndex == 4 ? Colors.blue : Colors.grey,
            ),
            label: '',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,
        showSelectedLabels: false,
        showUnselectedLabels: false,
        backgroundColor: Colors.white,
        onTap: _onItemTapped,
        type: BottomNavigationBarType.fixed,
      ),
    );
  }
}
