import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shopping/models/model_product.dart';
import 'package:shopping/viewmodels/post_view_model.dart';

// UI State Enum

// CategoryScreen Widget
class CategoryScreen extends StatefulWidget {
  const CategoryScreen({super.key});

  @override
  _CategoryScreenState createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  List<Category> categories = getCategories();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      drawer: Drawer(),
      appBar: AppBar(title: Text("Categories")),
      body: ListView.builder(
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final category = categories[index];
          return CategoryRow(category: category);
        },
      ),
    );
  }
}

// CategoryRow Widget
class CategoryRow extends StatefulWidget {
  final Category category;

  const CategoryRow({super.key, required this.category});

  @override
  _CategoryRowState createState() => _CategoryRowState();
}

class _CategoryRowState extends State<CategoryRow>
    with AutomaticKeepAliveClientMixin<CategoryRow> {
  final ProductViewModel _viewModel = ProductViewModel();

  @override
  void initState() {
    super.initState();
    _viewModel.fetchProducts(widget.category.id);
  }

  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 16.0),
          shape: const Border(
            top: BorderSide(color: Colors.grey, width: 2),
          ),
          leading: ClipRRect(
            borderRadius: BorderRadius.circular(4.0),
            child: Image.asset(
              widget.category.image,
              fit: BoxFit.fitHeight,
              width: 45,
              height: 45,
            ),
          ),
          title: Text(
            widget.category.title,
            maxLines: 1,
            style: const TextStyle(
              fontSize: 16,
              color: Colors.black,
              fontFamily: 'montserrat',
              fontWeight: FontWeight.w800,
            ),
          ),
          subtitle: Text(
            widget.category.subtitle,
            maxLines: 1,
            style: const TextStyle(
              fontSize: 12,
              color: Colors.grey,
              fontFamily: 'montserrat',
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        SizedBox(
          height: 200,
          child: AnimatedBuilder(
            animation: _viewModel,
            builder: (context, _) {
              if (_viewModel.uiState == UiState.loading) {
                return Center(child: CircularProgressIndicator());
              } else if (_viewModel.uiState == UiState.error) {
                return Center(child: Text('Error loading products'));
              } else {
                return ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: _viewModel.products.length,
                  itemBuilder: (context, index) {
                    final product = _viewModel.products[index];
                    return SizedBox(
                      width: 170, // Set a fixed width for each ProductCard
                      child: ProductCard(product: product),
                    );
                  },
                );
              }
            },
          ),
        ),
      ],
    );
  }
}

class ProductCard extends StatelessWidget {
  final Product product;

  const ProductCard({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        children: [
          Image.network(product.thumbnail, height: 100, width: 100),
          SizedBox(height: 10),
          Text(product.title),
          Text('\$${product.price}'),
        ],
      ),
    );
  }
}

// Main Function
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      systemNavigationBarColor: Colors.transparent,
    ),
  );
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: CategoryScreen(),
  ));
}
